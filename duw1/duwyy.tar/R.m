function out = R( fi )
    out = [cos(fi) -sin(fi); sin(fi) cos(fi)];
end

