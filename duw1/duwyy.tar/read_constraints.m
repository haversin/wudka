function [ rot, tra ] = read_constraints( file_rot, file_tra, points, bodies)
    i = 1;
    % rot = [body_i; body_j; s(i); s(j)]
    if(file_rot > 0)
        while ~feof(file_rot)
            a(:) = textscan(file_rot, '%f %f %s\n', 1);
            v1 = [a{1} a{2}]';
            if(v1(1) == 0)
                v2 = points(a{3}{1});
            else
                v2 = points(a{3}{1}) - bodies(:,v1(1));
            end
            if(v1(2) == 0)
                v3 = points(a{3}{1});
            else
                v3 = points(a{3}{1}) - bodies(:,v1(2));
            end
            rot(:,i) = [v1; v2; v3];
            i = i+1;
        end
    end
    
    i = 1;
    % tra = [body_i; body_j; sai; sbj; vj; fi0]
    if(file_tra > 0)
        while ~feof(file_tra)
            b(:) = textscan(file_tra, '%f %f %s %s\n', 1);
            bod = [b{1} b{2}]';
            if(bod(1) == 0)
                sai = points(b{3}{1});
            else
                sai = points(b{3}{1}) - bodies(:,bod(1));
            end
            if(bod(2) == 0)
                sbj = points(b{4}{1});
            else
                sbj = points(b{4}{1}) - bodies(:,bod(2));
            end
            vj = [0, -1; 1, 0]*(points(b{4}{1}) - points(b{3}{1}));
            tra(:,i) = [bod; sai; sbj; vj; 0];
            i = i+1;
        end
    end
    %tra = 0;
end

